# Week 2 Challenge 03

Html layout for main bookshelf page based on this sketch

![sketch](https://github.com/emrszon/JS-School/blob/master/C03/jobsity_bookshelf.jpg)

All files are in this repo-folder.

You can download the .zip that contains all the files